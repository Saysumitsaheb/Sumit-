-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 17, 2018 at 04:04 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tolltax`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `vehicle` varchar(20) NOT NULL,
  `type` varchar(10) NOT NULL,
  `address` varchar(300) NOT NULL,
  `route_list` varchar(30) NOT NULL,
  `transactionnum` varchar(10) NOT NULL,
  `payable` varchar(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `fname`, `lname`, `contact`, `vehicle`, `type`, `address`, `route_list`, `transactionnum`, `payable`) VALUES
(29, 'faef', 'fsefe', 'sfes', '0', 'Truck', 'sefes', '25', 'RCDSCBH3', '30'),
(32, 'jgdshvhd', 'vhvghvhvh', '66444496496', '666161', 'Truck', 'vhvhvhvh', '30', '7443SBX6', '40'),
(36, 'Nasirul', 'Sk', '7679668020', 'WB02P3520', 'Truck', 'Golapbag, Burdwan', '30', 'OI5ASX2W', '30'),
(37, 'Sumit', 'Ghosh', '9856215255', 'AP68SD6515', 'Bus', 'Golapbag, Burdwan', '19', '5201DD5A', '30');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `message` varchar(300) NOT NULL,
  `number` varchar(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `subject`, `message`, `number`) VALUES
(1, 'Sumit Modal', 'sumit@gmail.com', 'jabjbbxh hxhsb hsbhs', 'kmskds sjdnjsnd sjnjd sdhsdsh sbdshdbsd shb dhsd', '59'),
(2, 'Joy', 'joy@gmail.com', 'bdsdbhsbdhshbdhs shdhsd shd', 'kndnjnd wjdhw d dwhbdhwd wbdwhbdhw dwh dhw dw whd whdw d', '2'),
(3, 'Rabindra', 'rabindra@gmail.com', 'kwndnsjd sa dh d dhs dhs de d', 'mkekmrkemr ejwrjer ejrjerje ejrnejrn er ewhrehr ewhrewr ehr er eh', '7');

-- --------------------------------------------------------

--
-- Table structure for table `route`
--

CREATE TABLE IF NOT EXISTS `route` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `route` varchar(300) NOT NULL,
  `price` varchar(30) NOT NULL,
  `type` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `route`
--

INSERT INTO `route` (`id`, `route`, `price`, `type`) VALUES
(0, 'From - To', 'Toll fees', 'Car'),
(1, 'Durgapur-Burdwan', '10', 'Car'),
(2, 'Durgapur-Dankuni', '20', 'Car'),
(3, 'Durgapur-Kolkata', '30', 'Car'),
(4, 'Burdwan-Durgapur', '10', 'Car'),
(5, 'Burdwan-Dankuni', '10', 'Car'),
(6, 'Burdwan-Kolkata', '20', 'Car'),
(7, 'Dankuni-Kolkata', '10', 'Car'),
(8, 'Dankuni-Burdwan', '10', 'Car'),
(9, 'Dankuni-Durgapur', '20', 'Car'),
(10, 'Kolkata-Dankuni', '10', 'Car'),
(11, 'Kolkata-Burdwan', '20', 'Car'),
(12, 'Kolkata-Durgapur', '30', 'Car'),
(13, 'From - To', 'Toll fees', 'Bus'),
(14, 'Durgapur-Burdwan', '20', 'Bus'),
(15, 'Durgapur-Dankuni', '30', 'Bus'),
(16, 'Durgapur-Kolkata', '40', 'Bus'),
(17, 'Burdwan-Durgapur', '20', 'Bus'),
(18, 'Burdwan-Dankuni', '20', 'Bus'),
(19, 'Burdwan-Kolkata', '30', 'Bus'),
(20, 'Dankuni-Kolkata', '20', 'Bus'),
(21, 'Dankuni-Burdwan', '20', 'Bus'),
(22, 'Dankuni-Durgapur', '30', 'Bus'),
(23, 'Kolkata-Dankuni', '20', 'Bus'),
(24, 'Kolkata-Burdwan', '30', 'Bus'),
(25, 'Kolkata-Durgapur', '40', 'Bus'),
(26, 'From - To', 'Toll fees', 'Truck'),
(27, 'Durgapur-Burdwan', '30', 'Truck'),
(28, 'Durgapur-Dankuni', '40', 'Truck'),
(29, 'Durgapur-Kolkata', '50', 'Truck'),
(30, 'Burdwan-Durgapur', '30', 'Truck'),
(31, 'Burdwan-Dankuni', '30', 'Truck'),
(32, 'Burdwan-Kolkata', '40', 'Truck'),
(33, 'Dankuni-Kolkata', '30', 'Truck'),
(34, 'Dankuni-Burdwan', '30', 'Truck'),
(35, 'Dankuni-Durgapur', '40', 'Truck'),
(36, 'Kolkata-Dankuni', '30', 'Truck'),
(37, 'Kolkata-Burdwan', '40', 'Truck'),
(38, 'Kolkata-Durgapur', '50', 'Truck');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE IF NOT EXISTS `transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(11) NOT NULL,
  `route_list` varchar(11) NOT NULL,
  `type` varchar(10) NOT NULL,
  `transactionnum` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`id`, `date`, `route_list`, `type`, `transactionnum`) VALUES
(17, '25/05/2017', '4', '', 'OERTS55O'),
(18, '04/05/2017', '4', '', 'Y4A0GHX7'),
(19, '10/05/2017', '4', '', 'ZZ0SGVYC'),
(20, '17/05/2017', '4', '', 'H7S2FBCY'),
(21, '20/05/2017', '4', '', 'YAIAMNEK'),
(22, '20/05/2017', '4', '', '5JVDXDTY'),
(25, '04/05/2017', '4', '', 'XT6IPSHP'),
(26, '18/05/2017', '4', 'Truck', 'M6FRCPGK'),
(27, '20/05/2017', '3', 'Car', 'H0OZONGT'),
(28, '04/05/2017', '13', 'Bus', 'POA5BNQX'),
(29, '11/05/2017', '25', 'Truck', 'RCDSCBH3'),
(30, '06/05/2017', '1', 'Car', 'GJLNU5F2'),
(31, '06/05/2017', '1', 'Car', 'MB6RX6JC'),
(32, '10/05/2017', '30', 'Truck', '7443SBX6'),
(33, '25/05/2017', '1', 'Car', 'GONNE5A1'),
(34, '', '15', 'Bus', 'K6ZC2DVN'),
(35, '26/05/2017', '16', 'Bus', '5RN4DILT'),
(36, '18/02/2018', '30', 'Truck', 'OI5ASX2W'),
(37, '20/02/2018', '19', 'Bus', '5201DD5A');
